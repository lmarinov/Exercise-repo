package aquarium.entities.decorations;

public class Plant extends BaseDecoration{
    protected Plant() {
        super(5, 10);
    }
}
