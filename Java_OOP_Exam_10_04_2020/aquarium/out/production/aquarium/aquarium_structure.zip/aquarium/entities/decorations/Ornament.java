package aquarium.entities.decorations;

public class Ornament extends BaseDecoration{
    protected Ornament() {
        super(1, 5);
    }
}
