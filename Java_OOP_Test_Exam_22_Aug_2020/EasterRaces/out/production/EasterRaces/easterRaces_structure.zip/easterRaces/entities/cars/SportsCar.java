package easterRaces.entities.cars;

import easterRaces.common.ExceptionMessages;

public class SportsCar extends  BaseCar{
//    private static final double SPORTS_CAR_CUBIC_CENTIMETERS = 3000.0;
//    private static final int MIN_HORSE_POWER = 250;
//    private static final int MAX_HORSE_POWER = 450;

    public SportsCar(String model, int horsePower) {
        super(model, setHorsePower(horsePower), 3000);
//        super.setMinHorsePower(MIN_HORSE_POWER);
//        super.setMaxHorsePower(MAX_HORSE_POWER);
    }

    private static int setHorsePower(int horsePower) {
        if (horsePower < 250 || horsePower > 450) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.INVALID_HORSE_POWER, horsePower));
        }
        return horsePower;
    }
}
