package easterRaces.entities.cars;

import easterRaces.common.ExceptionMessages;

public class MuscleCar extends BaseCar{
//    private static final double MUSCLE_CAR_CUBIC_CENTIMETERS = 5000.0;
//    private static final int MIN_HORSE_POWER = 400;
//    private static final int MAX_HORSE_POWER = 600;

    public MuscleCar(String model, int horsePower) {
        super(model, setHorsePower(horsePower), 5000);
//        super.setMinHorsePower(MIN_HORSE_POWER);
//        super.setMaxHorsePower(MAX_HORSE_POWER);
    }


    private static int setHorsePower(int horsePower) {
        if (horsePower < 400 || horsePower > 600) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.INVALID_HORSE_POWER, horsePower));
        }
        return horsePower;
    }
}
