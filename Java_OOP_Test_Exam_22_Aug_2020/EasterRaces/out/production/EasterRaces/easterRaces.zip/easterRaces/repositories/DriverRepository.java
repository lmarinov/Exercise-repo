package easterRaces.repositories;

import easterRaces.entities.interfaces.Driver;

public class DriverRepository<T> extends RepositoryImpl<Driver> {
    public DriverRepository() {
        super();
    }

    @Override
    public Driver getByName(String name) {
        return this.getAll().stream().filter(driver -> driver.getName().equals(name)).findFirst().orElse(null);
    }

}
