package easterRaces.repositories;

import easterRaces.entities.interfaces.Car;

public class CarRepository<T> extends RepositoryImpl<Car> {
    public CarRepository() {
        super();
    }

    @Override
    public Car getByName(String model) {
        return this.getAll().stream().filter(car -> car.getModel().equals(model)).findFirst().orElse(null);
    }
}
