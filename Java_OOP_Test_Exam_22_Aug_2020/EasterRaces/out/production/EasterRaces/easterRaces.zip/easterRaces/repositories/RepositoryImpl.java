package easterRaces.repositories;

import easterRaces.repositories.interfaces.Repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

// Judge does not understand implementing Repository<T>

public abstract class RepositoryImpl<T> implements Repository<T> {
    private List<T> models;

    protected RepositoryImpl() {
        this.models = new ArrayList<>();
    }

    @Override
    public void add(T model) {
        this.models.add(model);
    }

    @Override
    public boolean remove(T model) {
        return this.models.remove(model);
    }

    @Override
    public Collection<T> getAll() {
        return Collections.unmodifiableList(this.models);
    }
}
