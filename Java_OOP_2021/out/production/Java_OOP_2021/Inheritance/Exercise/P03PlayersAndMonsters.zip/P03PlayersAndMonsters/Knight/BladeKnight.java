package P03PlayersAndMonsters.Knight;

public class BladeKnight extends DarkKnight{
    public BladeKnight(String username, int level) {
        super(username, level);
    }


}
