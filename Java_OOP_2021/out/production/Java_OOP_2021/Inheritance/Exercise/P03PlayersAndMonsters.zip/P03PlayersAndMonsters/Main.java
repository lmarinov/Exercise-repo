package P03PlayersAndMonsters;

import P03PlayersAndMonsters.Elf.MuseElf;
import P03PlayersAndMonsters.Knight.BladeKnight;
import P03PlayersAndMonsters.Wizard.SoulMaster;

public class Main {
    public static void main(String[] args) {
        MuseElf museElf = new MuseElf("MuseElf", 15);
        SoulMaster soulMaster = new SoulMaster("SoulMaster", 22);
        BladeKnight bladeKnight = new BladeKnight("BladeMaster", 31);

        System.out.println(museElf);
        System.out.println(soulMaster);
        System.out.println(bladeKnight);
    }
}
