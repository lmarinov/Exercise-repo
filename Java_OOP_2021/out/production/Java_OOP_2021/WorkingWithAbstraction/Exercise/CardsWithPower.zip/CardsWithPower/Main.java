package WorkingWithAbstraction.Exercise.CardsWithPower;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String firstLine = reader.readLine();
        String secondLine = reader.readLine();

        System.out.printf("Card name: %s of %s; Card power: %d",
                CardRank.valueOf(CardRank.class, firstLine).name(),
                CardSuit.valueOf(CardSuit.class, secondLine).name(),
                CardRank.valueOf(CardRank.class, firstLine).getValue() + CardSuit.valueOf(CardSuit.class, secondLine).getValue());

    }
}
