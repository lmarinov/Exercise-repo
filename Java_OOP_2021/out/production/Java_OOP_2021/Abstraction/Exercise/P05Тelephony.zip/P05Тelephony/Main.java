package P05Тelephony;

public class Main {
    public static void main(String[] args) {

    }
}
