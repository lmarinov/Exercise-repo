package ReflectionAndAnnotations.Exercise.barracksWars.interfaces;

public interface UnitFactory {

    Unit createUnit(String unitType);
}