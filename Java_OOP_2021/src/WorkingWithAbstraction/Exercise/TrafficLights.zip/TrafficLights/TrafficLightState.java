package WorkingWithAbstraction.Exercise.TrafficLights;

public enum TrafficLightState {
    RED,
    GREEN,
    YELLOW;

}
