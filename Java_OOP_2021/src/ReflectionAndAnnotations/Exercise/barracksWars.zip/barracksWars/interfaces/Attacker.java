package ReflectionAndAnnotations.Exercise.barracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
