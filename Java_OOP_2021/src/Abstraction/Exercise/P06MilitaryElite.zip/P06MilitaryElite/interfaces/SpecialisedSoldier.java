package Abstraction.Exercise.P06MilitaryElite.interfaces;

public interface SpecialisedSoldier extends Private{
    String getCorps();
}
