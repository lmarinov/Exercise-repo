package Abstraction.Exercise.P06MilitaryElite.interfaces;

public interface Spy extends Soldier{
    String getCodeNumber();
}
